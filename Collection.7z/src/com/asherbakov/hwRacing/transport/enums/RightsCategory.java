package com.asherbakov.hwRacing.transport.enums;

public enum RightsCategory {
    B,
    C,
    D
}
