package com.asherbakov.hw2;

public class Main {
    public static void main(String[] args) {

    }
}
