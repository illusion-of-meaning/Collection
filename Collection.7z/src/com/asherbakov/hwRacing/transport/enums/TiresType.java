package com.asherbakov.hwRacing.transport.enums;

public enum TiresType {
    Summer,
    Winter
}
