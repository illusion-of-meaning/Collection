package com.asherbakov.hwRacing.drivers;

import com.asherbakov.hwRacing.transport.Bus;

public class DriverCategoryD extends Driver<Bus> {

    public DriverCategoryD(String fullName, int experience, Bus bus) {
        super(fullName, experience, bus);
    }


}
