package com.asherbakov.hwRacing.sponsors;

import java.util.Objects;

public abstract class Sponsor {
    private String name;
    private double sponsorship;

    public Sponsor(String name, double sponsorship) {
        if (name != null && !name.isBlank()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Спонсор не задан");
        }
        if (sponsorship >= 0) {
            this.sponsorship = sponsorship;
        } else {
            throw new IllegalArgumentException("Спонсорская помощь не может быть отрицательной");
        }
    }

    private void sponsorTheRace() {
        System.out.printf("Спонсор %s проспонсировал заезд на %.2f", this.name, this.sponsorship);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Sponsor sponsor = (Sponsor) o;
        return name.equals(sponsor.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    @Override
    public String toString() {
        return "Sponsor{" +
                "name='" + name + '\'' +
                ", sponsorship=" + sponsorship +
                '}';
    }
}
