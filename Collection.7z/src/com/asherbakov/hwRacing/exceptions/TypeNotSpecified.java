package com.asherbakov.hwRacing.exceptions;

public class TypeNotSpecified extends Exception {
    public TypeNotSpecified() {
    }

    public TypeNotSpecified(String message) {
        super(message);
    }
}
