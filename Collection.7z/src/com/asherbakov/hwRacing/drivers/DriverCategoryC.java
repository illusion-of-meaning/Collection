package com.asherbakov.hwRacing.drivers;

import com.asherbakov.hwRacing.transport.Train;

public class DriverCategoryC extends Driver<Train> {

    public DriverCategoryC(String fullName, int experience, Train train) {
        super(fullName, experience, train);
    }

}
