package com.asherbakov.hwRacing.interfaces;

public interface Compating {
    void pitStop();
    void bestTime();
    void maximumSpeed();

}
