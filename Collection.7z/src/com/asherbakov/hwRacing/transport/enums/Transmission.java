package com.asherbakov.hwRacing.transport.enums;

public enum Transmission {
    AT,
    MT
}
