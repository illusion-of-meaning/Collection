package com.asherbakov.hwRacing.category;

public class Category {
}
