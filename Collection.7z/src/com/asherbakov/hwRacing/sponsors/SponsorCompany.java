package com.asherbakov.hwRacing.sponsors;

public class SponsorCompany extends Sponsor {
    public SponsorCompany(String name, double sponsorship) {
        super(name, sponsorship);
    }
}
