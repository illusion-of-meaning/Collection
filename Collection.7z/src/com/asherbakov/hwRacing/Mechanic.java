package com.asherbakov.hwRacing;

public class Mechanic {
    private String firstName;
    private String lastName;
    private String companyName;

    public void fixСar() {

    }

    public void carryMaintenance() {

    }
}
