package com.asherbakov.hwRacing.drivers;

import com.asherbakov.hwRacing.transport.Car;

public class DriverCategoryB extends Driver<Car> {
    public DriverCategoryB(String fullName, int experience, Car car) {
        super(fullName, experience, car);
    }
}
